package com.parent.app.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.parent.app.model.CircularDetails;
import com.parent.app.repository.CircularRepository;
import com.parent.app.service.CircularService;


@Service
public class CircularImpl implements CircularService {
	
	@Autowired
	private CircularRepository circularRepo;
	
	@Override
	public List<CircularDetails> listDetails() {
		// TODO Auto-generated method stub
		return circularRepo.findAll();	
	}

	@Override
	public CircularDetails addCircularDetail(CircularDetails circularDetails) {
		// TODO Auto-generated method stub
		
		return circularRepo.save(circularDetails);
	}

	
	
}
