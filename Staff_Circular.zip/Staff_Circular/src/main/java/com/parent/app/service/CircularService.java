package com.parent.app.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.parent.app.model.CircularDetails;


@Service
public interface CircularService {
	
	List<CircularDetails> listDetails();

	CircularDetails addCircularDetail(CircularDetails parentDetails);

}
