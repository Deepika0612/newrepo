package com.parent.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;


@Entity
@Table(name = "CircularDetails")
public class CircularDetails {

		@Id
		@SequenceGenerator(initialValue = 1, name = "CircularId")
		@GeneratedValue(generator = "CircularId")
		private int circularId;
		
		@Pattern(regexp="^[a-zA-Z0-9\s]+$",message="Name must be alphabets with spaces")
		private String informText;
		
		@Pattern(regexp="^[a-zA-Z\s]+$",message="Name must be alphabets with spaces")
		private String postedBy;
		
		@Column(name = "notifyDate", columnDefinition = "DATE")
	    private java.sql.Date notifyDate;
		
		public int getCircularId() {
			return circularId;
		}
		public void setCircularId(int circularId) {
			this.circularId = circularId;
			}
		public String getInformText() {
			return informText;
		}
		public void setInformText(String informText) {
			this.informText = informText;
		}
		public String getPostedBy() {
			return postedBy;
		}
		public void setPostedBy(String postedBy) {
			this.postedBy = postedBy;
		}
		public java.sql.Date getNotifyDate() {
			return notifyDate;
		}
		public void setNotifyDate(java.sql.Date notifyDate) {
			this.notifyDate = notifyDate;
		}
		
}

