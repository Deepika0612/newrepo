package com.parent.app.service;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.parent.app.model.ParentUpdateDetails;

@Service
public interface UpdateService {
	
	List<ParentUpdateDetails> listDetails();
	
	ResponseEntity<Object> getParentDetail(int Id);

	ResponseEntity<String> updateParentDetail(int Id, ParentUpdateDetails parentUpdateDetails);
	
	ResponseEntity<String> approveParentDetail(int Id, ParentUpdateDetails parentUpdateDetails);

	ResponseEntity<String> rejectParentDetail(int id, ParentUpdateDetails parentDetails);
	
	


}
