package com.parent.app.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.parent.app.model.ParentUpdateDetails;
import com.parent.app.service.UpdateService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/a")
public class ParentUpdateController {
	
	@Autowired
	private UpdateService updateService;
	
	@GetMapping("/list")
	public List<ParentUpdateDetails> getAllParentDetails() {
		return updateService.listDetails();
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<Object> getParentDetails(@PathVariable(value = "id") int Id) {
		return updateService.getParentDetail(Id);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateParentDetails(@PathVariable(value = "id") int Id,
			@RequestBody ParentUpdateDetails parentDetails) {

		return updateService.updateParentDetail(Id, parentDetails);
	}
	
	
	@PutMapping("/approved/{id}")
	public ResponseEntity<String> approveParentDetails(@PathVariable(value = "id") int Id,
			@RequestBody ParentUpdateDetails parentDetails) {

		return updateService.approveParentDetail(Id, parentDetails);
	}
	 
	@PutMapping("/rejected/{id}")
	public ResponseEntity<String> rejectedParentDetails(@PathVariable(value = "id") int Id,
			@RequestBody ParentUpdateDetails parentDetails) {

		return updateService.rejectParentDetail(Id, parentDetails);
	}
	 
}

