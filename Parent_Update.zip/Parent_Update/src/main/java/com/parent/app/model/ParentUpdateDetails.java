package com.parent.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;


@Entity
@Table(name = "ParentDetails")
public class ParentUpdateDetails {

	@Id
	@SequenceGenerator(initialValue = 1000000000, name = "Id")
	@GeneratedValue(generator = "Id")
	private int id;	
	
	@Pattern(regexp="^[a-zA-Z\s]+$",message="Student Name must be alphabets with spaces")
	private String studentName;
	
	@Pattern(regexp="^[a-zA-Z\s]+$",message="Parent Name must be alphabets with spaces")
	private String parentName;
	
	private String address;
	
	@Pattern(regexp="^[a-zA-Z\s]+$",message="state must be alphabets with spaces")
	private String state;
	
	@Pattern(regexp="^[a-zA-Z\s]+$",message="country must be alphabets with spaces")
	private String country;
	
	@Pattern(regexp="^[a-zA-Z]+$",message="city must be alphabets with no spaces")
	private String city;
	
	@Pattern(regexp="^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$",message="ZipCode must have exactly 6 numbers")
	private String zipCode;
	
	@Pattern(regexp="^[a-z0-9@.]+$",message="enter valid email id")
	private String emailId;

	@Pattern(regexp="^[a-zA-Z\s]+$",message="Name must be alphabets with spaces")
	private String primaryContactPersonName;
	
	@Pattern(regexp="^[0-9]{3}[0-9]{3}[0-9]{4}$",message="enter valid primary phone number")
	private String primaryMobile;
	
	@Pattern(regexp="^[a-zA-Z\s]+$",message="Parent Name must be alphabets with spaces")
	private String secondaryContactPersonName;
	
	@Pattern(regexp="^[0-9]{3}[0-9]{3}[0-9]{4}$",message="enter valid secondary phone number")
	private String secondaryMobile;
	
	
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getStudentName() {
			return studentName;
		}
		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}
		public String getParentName() {
			return parentName;
		}
		public void setParentName(String parentName) {
			this.parentName = parentName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getZipCode() {
			return zipCode;
		}
		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getPrimaryContactPersonName() {
			return primaryContactPersonName;
		}
		public void setPrimaryContactPersonName(String primaryContactPersonName) {
			this.primaryContactPersonName = primaryContactPersonName;
		}
		public String getPrimaryMobile() {
			return primaryMobile;
		}
		public void setPrimaryMobile(String primaryMobile) {
			this.primaryMobile = primaryMobile;
		}
		public String getSecondaryContactPersonName() {
			return secondaryContactPersonName;
		}
		public void setSecondaryContactPersonName(String secondaryContactPersonName) {
			this.secondaryContactPersonName = secondaryContactPersonName;
		}
		public String getSecondaryMobile() {
			return secondaryMobile;
		}
		public void setSecondaryMobile(String secondaryMobile) {
			this.secondaryMobile = secondaryMobile;
		}
}

