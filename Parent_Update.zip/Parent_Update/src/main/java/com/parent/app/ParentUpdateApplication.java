package com.parent.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParentUpdateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParentUpdateApplication.class, args);
	
	}
	

}
